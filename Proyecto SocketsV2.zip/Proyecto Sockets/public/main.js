/*  creamos la variable que permitirá al frontend conectarse a nuestro backend*/

var socket = io.connect('http://localhost:3003', {'forcellew':true});

/* esto manda el mensaje de connect y aparece en el console.log */