var express = require('express');
var app = express();
var server = require ('http').Server(app);

/* Aqui usamos un middleware para usar elementos estaticos en la sección publica de la aplicada */
app.use(express.static('public'));

var io= require ('socket.io')(server);

app.get('/', function(req, res){
res.status(200).send("Hola Mundo");
});

/* De esti forma activamos el socket para que este escuche cuando mandamos un mensaje de control
por consola para saber que está pasando y tenemos que hacer que el mensaje venga del propio navegador web mediante html y JS */

io.on('connection', function(socket){
    console.log('Alguien se ha conectado al socket')
});

server.listen(3003, function(){
    console.log("El servidor esta corriendo en http://localhost:3003");
})